package com.app.dto;

import lombok.Data;

@Data
public class PropertyTypeDTO {
    private int property_type_id;

}
