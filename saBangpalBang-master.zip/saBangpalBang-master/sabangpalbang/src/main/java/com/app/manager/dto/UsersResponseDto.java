package com.app.manager.dto;

import lombok.Data;

@Data
public class UsersResponseDto {
	private int user_id;
	private String  id;
	private String email;
	private String role;
}

